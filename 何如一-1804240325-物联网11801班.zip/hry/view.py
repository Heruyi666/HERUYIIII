from django.shortcuts import HttpResponse,render
import json
import mysql.connector


def a(request):
    a = 3
    b = []

    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        passwd="HERUYI991211",
        port="3306",
        database='mysql'
    )
    mycursor = mydb.cursor()
    sql = """SELECT zz from hry"""
    mycursor.execute(sql)
    d = mycursor.fetchall()
    for i in d:
        b.append(i[0])
    d = json.dumps(b)

    return render(request,"b.html",locals())